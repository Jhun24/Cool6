$(function(){
   
    $(".teamJoin").click(function teamJoin(){
       $(location).attr('href','team.html') 
    });
    
});